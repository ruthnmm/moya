import { BadgeDollarSign, Banknote, CarFront, Handshake, MapPinned } from "lucide-react";
import { T } from "@/components/language-provider";
import { SectionHeading } from "@/components/section-heading";

const reasons = [
  { titleKey: "why.quality", icon: CarFront },
  { titleKey: "why.financing", icon: Banknote },
  { titleKey: "why.service", icon: Handshake },
  { titleKey: "why.local", icon: MapPinned },
  { titleKey: "why.prices", icon: BadgeDollarSign },
] as const;

export function WhyChooseUs() {
  return (
    <section className="bg-white py-16">
      <div className="container-page">
        <SectionHeading
          kickerKey="why.kicker"
          titleKey="why.title"
          copyKey="why.copy"
        />
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {reasons.map(({ titleKey, icon: Icon }) => (
            <div key={titleKey} className="rounded-sm border border-black bg-white p-5">
              <Icon className="h-9 w-9 text-red-700" aria-hidden="true" />
              <T k={titleKey} as="p" className="mt-4 text-base font-black uppercase text-black" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

import type { Metadata } from "next";
import { CheckCircle } from "lucide-react";
import { T } from "@/components/language-provider";
import { LeadForm } from "@/components/lead-form";

export const metadata: Metadata = {
  title: "Used Car Financing",
  description: "Apply for flexible used car financing at Moya Auto Sales in Coachella, CA.",
};

export default function FinancingPage() {
  return (
    <section className="bg-white py-12 md:py-16">
      <div className="container-page grid gap-10 lg:grid-cols-[0.9fr_1.1fr]">
        <div>
          <T k="financing.kicker" as="p" className="text-sm font-black uppercase tracking-wide text-red-700" />
          <T k="financing.title" as="h1" className="mt-2 text-4xl font-black uppercase text-black md:text-5xl" />
          <T k="financing.copy" as="p" className="mt-5 text-lg leading-8 text-black" />
          <div className="mt-8 grid gap-4">
            {(["financing.point1", "financing.point2", "financing.point3"] as const).map((item) => (
              <p key={item} className="flex items-center gap-3 font-bold text-black">
                <CheckCircle className="h-5 w-5 text-red-700" aria-hidden="true" />
                <T k={item} />
              </p>
            ))}
          </div>
        </div>
        <div className="rounded-sm border border-black bg-white p-6 shadow-sm md:p-8">
          <LeadForm type="financing" buttonLabel="form.applyNow" />
        </div>
      </div>
    </section>
  );
}

"use client";

import { useState } from "react";
import { submitLead } from "@/app/actions/leads";
import { useLanguage } from "@/components/language-provider";
import type { TranslationKey } from "@/lib/i18n";

type Props = {
  type: "contact" | "financing";
  buttonLabel: TranslationKey;
};

export function LeadForm({ type, buttonLabel }: Props) {
  const { t } = useLanguage();
  const [status, setStatus] = useState<string | null>(null);

  async function onSubmit(formData: FormData) {
    setStatus(t("form.sending"));
    const result = await submitLead(formData);
    setStatus(t(result.messageKey));
  }

  return (
    <form action={onSubmit} className="grid gap-4">
      <input type="hidden" name="type" value={type} />
      <label className="grid gap-2 text-sm font-bold text-black">
        {t("form.name")}
        <input
          name="name"
          required
          className="focus-ring rounded-sm border border-black px-4 py-3"
          placeholder={t("form.namePlaceholder")}
        />
      </label>
      <label className="grid gap-2 text-sm font-bold text-black">
        {t("form.phone")}
        <input
          name="phone"
          type="tel"
          required
          className="focus-ring rounded-sm border border-black px-4 py-3"
          placeholder={t("form.phonePlaceholder")}
        />
      </label>
      <label className="grid gap-2 text-sm font-bold text-black">
        {t("form.message")}
        <textarea
          name="message"
          rows={5}
          className="focus-ring resize-y rounded-sm border border-black px-4 py-3"
          placeholder={t("form.messagePlaceholder")}
        />
      </label>
      <button
        type="submit"
        className="focus-ring rounded-sm bg-red-700 px-5 py-4 text-sm font-black uppercase text-white transition hover:bg-black"
      >
        {t(buttonLabel)}
      </button>
      {status ? <p className="text-sm font-bold text-black">{status}</p> : null}
    </form>
  );
}

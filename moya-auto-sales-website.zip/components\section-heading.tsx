import { T } from "@/components/language-provider";
import type { TranslationKey } from "@/lib/i18n";

export function SectionHeading({
  kicker,
  title,
  copy,
  kickerKey,
  titleKey,
  copyKey,
}: {
  kicker?: string;
  title?: string;
  copy?: string;
  kickerKey?: TranslationKey;
  titleKey?: TranslationKey;
  copyKey?: TranslationKey;
}) {
  return (
    <div className="max-w-3xl">
      {kickerKey ? (
        <T k={kickerKey} as="p" className="text-sm font-black uppercase tracking-wide text-red-700" />
      ) : kicker ? (
        <p className="text-sm font-black uppercase tracking-wide text-red-700">{kicker}</p>
      ) : null}
      {titleKey ? (
        <T k={titleKey} as="h2" className="mt-2 text-3xl font-black uppercase text-black md:text-4xl" />
      ) : (
        <h2 className="mt-2 text-3xl font-black uppercase text-black md:text-4xl">{title}</h2>
      )}
      {copyKey ? (
        <T k={copyKey} as="p" className="mt-4 text-base leading-7 text-black" />
      ) : copy ? (
        <p className="mt-4 text-base leading-7 text-black">{copy}</p>
      ) : null}
    </div>
  );
}

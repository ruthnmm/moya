"use server";

import { createSupabaseAdminClient } from "@/lib/supabase/server";

export async function submitLead(formData: FormData) {
  try {
    const type = String(formData.get("type") ?? "contact");
    const name = String(formData.get("name") ?? "").trim();

    if (!name) {
      return { ok: false, messageKey: "form.nameRequired" as const };
    }

    const monthlyIncome = String(formData.get("monthly_income") ?? "").trim();
    const supabase = createSupabaseAdminClient();
    const { error } = await supabase.from("leads").insert({
      type,
      name,
      phone: String(formData.get("phone") ?? "").trim() || null,
      monthly_income: monthlyIncome ? Number(monthlyIncome) : null,
      message: String(formData.get("message") ?? "").trim() || null,
    });

    if (error) {
      console.error(error);
      return { ok: false, messageKey: "form.error" as const };
    }

    return { ok: true, messageKey: "form.success" as const };
  } catch (error) {
    console.error(error);
    return { ok: false, messageKey: "form.configError" as const };
  }
}

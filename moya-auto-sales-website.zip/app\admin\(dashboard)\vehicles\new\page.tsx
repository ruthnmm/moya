import type { Metadata } from "next";
import { VehicleForm } from "@/components/vehicle-form";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Add Vehicle",
};

export default function NewVehiclePage() {
  return (
    <div>
      <p className="text-sm font-black uppercase text-red-700">Inventory</p>
      <h2 className="mb-6 text-3xl font-black uppercase text-black">Add Vehicle</h2>
      <VehicleForm />
    </div>
  );
}

import type { Metadata } from "next";
import { T } from "@/components/language-provider";
import { WhyChooseUs } from "@/components/why-choose-us";

export const metadata: Metadata = {
  title: "About Us",
  description: "Learn about Moya Auto Sales, a locally owned used car dealership in Coachella, CA.",
};

export default function AboutPage() {
  return (
    <>
      <section className="bg-black py-16 text-white">
        <div className="container-page max-w-4xl">
          <T k="about.kicker" as="p" className="text-sm font-black uppercase tracking-wide text-red-500" />
          <h1 className="mt-3 text-4xl font-black uppercase md:text-5xl">Moya Auto Sales</h1>
          <T k="about.copy" as="p" className="mt-6 text-lg leading-8 text-white" />
        </div>
      </section>
      <section className="bg-white py-16">
        <div className="container-page grid gap-8 md:grid-cols-3">
          <div>
            <T k="about.localTitle" as="p" className="text-xl font-black uppercase text-black" />
            <T k="about.localCopy" as="p" className="mt-3 leading-7 text-black" />
          </div>
          <div>
            <T k="about.practicalTitle" as="p" className="text-xl font-black uppercase text-black" />
            <T k="about.practicalCopy" as="p" className="mt-3 leading-7 text-black" />
          </div>
          <div>
            <T k="about.helpfulTitle" as="p" className="text-xl font-black uppercase text-black" />
            <T k="about.helpfulCopy" as="p" className="mt-3 leading-7 text-black" />
          </div>
        </div>
      </section>
      <WhyChooseUs />
    </>
  );
}

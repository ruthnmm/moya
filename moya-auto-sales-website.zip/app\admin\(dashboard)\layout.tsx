import Link from "next/link";
import { AdminLogoutButton } from "@/components/admin-logout-button";
import { requireAdmin } from "@/lib/admin";

export const dynamic = "force-dynamic";

export default async function AdminDashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  await requireAdmin();

  return (
    <section className="bg-white py-8 md:py-12">
      <div className="container-page">
        <div className="mb-6 flex flex-col justify-between gap-4 rounded-sm border border-black bg-white p-4 shadow-sm md:flex-row md:items-center">
          <div>
            <p className="text-sm font-black uppercase tracking-wide text-red-700">
              Moya Auto Sales
            </p>
            <h1 className="text-2xl font-black uppercase text-black">Admin Dashboard</h1>
          </div>
          <div className="flex flex-wrap gap-2">
            <AdminLink href="/admin">Vehicles</AdminLink>
            <AdminLink href="/admin/vehicles/new">Add Vehicle</AdminLink>
            <AdminLink href="/admin/leads">Leads</AdminLink>
            <AdminLogoutButton />
          </div>
        </div>
        {children}
      </div>
    </section>
  );
}

function AdminLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      className="focus-ring rounded-sm bg-black px-4 py-3 text-sm font-black uppercase text-white hover:bg-red-700"
    >
      {children}
    </Link>
  );
}

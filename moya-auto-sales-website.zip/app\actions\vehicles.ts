"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireAdmin } from "@/lib/admin";
import { createSupabaseAdminClient } from "@/lib/supabase/server";
import type { VehicleType } from "@/lib/types";

const imageBucket = "vehicle-images";

function value(formData: FormData, key: string) {
  return String(formData.get(key) ?? "").trim();
}

function boolValue(formData: FormData, key: string) {
  return formData.get(key) === "on";
}

function vehiclePayload(formData: FormData) {
  return {
    year: Number(value(formData, "year")),
    make: value(formData, "make"),
    model: value(formData, "model"),
    trim: value(formData, "trim") || null,
    mileage: Number(value(formData, "mileage")),
    price: Number(value(formData, "price")),
    vin: value(formData, "vin"),
    stock_number: value(formData, "stock_number"),
    transmission: value(formData, "transmission") || null,
    fuel_type: value(formData, "fuel_type") || null,
    exterior_color: value(formData, "exterior_color") || null,
    interior_color: value(formData, "interior_color") || null,
    vehicle_type: value(formData, "vehicle_type") as VehicleType,
    description: value(formData, "description") || null,
    features: value(formData, "features")
      .split(/\r?\n|,/)
      .map((feature) => feature.trim())
      .filter(Boolean),
    featured: boolValue(formData, "featured"),
    sold: boolValue(formData, "sold"),
    hidden: boolValue(formData, "hidden"),
  };
}

async function uploadImages(vehicleId: string, formData: FormData) {
  const supabase = createSupabaseAdminClient();
  const files = formData
    .getAll("images")
    .filter((file): file is File => file instanceof File && file.size > 0);

  for (const [index, file] of files.entries()) {
    const extension = file.name.split(".").pop() || "jpg";
    const path = `${vehicleId}/${Date.now()}-${index}.${extension}`;
    const { error: uploadError } = await supabase.storage
      .from(imageBucket)
      .upload(path, file, {
        cacheControl: "3600",
        upsert: false,
        contentType: file.type || "image/jpeg",
      });

    if (uploadError) {
      throw uploadError;
    }

    const {
      data: { publicUrl },
    } = supabase.storage.from(imageBucket).getPublicUrl(path);

    const { error: imageError } = await supabase.from("vehicle_images").insert({
      vehicle_id: vehicleId,
      image_url: publicUrl,
      sort_order: index,
    });

    if (imageError) {
      throw imageError;
    }
  }
}

function storagePathFromPublicUrl(imageUrl: string) {
  const marker = `/${imageBucket}/`;
  const [, path] = imageUrl.split(marker);
  return path ? decodeURIComponent(path) : null;
}

export async function createVehicle(formData: FormData) {
  await requireAdmin();
  const supabase = createSupabaseAdminClient();
  const { data, error } = await supabase
    .from("vehicles")
    .insert(vehiclePayload(formData))
    .select("id")
    .single();

  if (error) {
    throw error;
  }

  await uploadImages(data.id, formData);
  revalidatePath("/");
  revalidatePath("/inventory");
  redirect("/admin");
}

export async function updateVehicle(vehicleId: string, formData: FormData) {
  await requireAdmin();
  const supabase = createSupabaseAdminClient();
  const { error } = await supabase.from("vehicles").update(vehiclePayload(formData)).eq("id", vehicleId);

  if (error) {
    throw error;
  }

  await uploadImages(vehicleId, formData);
  revalidatePath("/");
  revalidatePath("/inventory");
  revalidatePath(`/inventory/${vehicleId}`);
  redirect("/admin");
}

export async function deleteVehicle(vehicleId: string) {
  await requireAdmin();
  const supabase = createSupabaseAdminClient();
  const { data: images } = await supabase
    .from("vehicle_images")
    .select("image_url")
    .eq("vehicle_id", vehicleId);
  const paths =
    images
      ?.map((image) => storagePathFromPublicUrl(image.image_url))
      .filter((path): path is string => Boolean(path)) ?? [];

  if (paths.length) {
    await supabase.storage.from(imageBucket).remove(paths);
  }

  const { error } = await supabase.from("vehicles").delete().eq("id", vehicleId);

  if (error) {
    throw error;
  }

  revalidatePath("/");
  revalidatePath("/inventory");
  redirect("/admin");
}

export async function deleteVehicleImage(imageId: string, vehicleId: string) {
  await requireAdmin();
  const supabase = createSupabaseAdminClient();
  const { data: image } = await supabase
    .from("vehicle_images")
    .select("image_url")
    .eq("id", imageId)
    .single();
  const path = image?.image_url ? storagePathFromPublicUrl(image.image_url) : null;

  if (path) {
    await supabase.storage.from(imageBucket).remove([path]);
  }

  const { error } = await supabase.from("vehicle_images").delete().eq("id", imageId);

  if (error) {
    throw error;
  }

  revalidatePath(`/admin/vehicles/${vehicleId}/edit`);
  revalidatePath(`/inventory/${vehicleId}`);
}

import type { Metadata } from "next";
import { T } from "@/components/language-provider";
import { InventoryFilters } from "@/components/inventory-filters";
import { getVisibleVehicles } from "@/lib/vehicles";

export const metadata: Metadata = {
  title: "Used Vehicle Inventory",
  description: "Browse used cars, trucks, SUVs, coupes, and vans at Moya Auto Sales in Coachella, CA.",
};

export default async function InventoryPage() {
  const vehicles = (await getVisibleVehicles()).filter((vehicle) => !vehicle.sold);

  return (
    <section className="bg-white py-12 md:py-16">
      <div className="container-page">
        <T k="inventory.kicker" as="p" className="text-sm font-black uppercase tracking-wide text-red-700" />
        <T k="inventory.title" as="h1" className="mt-2 text-4xl font-black uppercase text-black md:text-5xl" />
        <T k="inventory.copy" as="p" className="mt-4 max-w-3xl text-lg leading-8 text-black" />
        <div className="mt-10">
          <InventoryFilters vehicles={vehicles} />
        </div>
      </div>
    </section>
  );
}

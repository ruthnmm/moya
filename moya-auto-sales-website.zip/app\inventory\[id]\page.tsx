import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Check, Gauge, MapPin, Phone } from "lucide-react";
import type { Metadata } from "next";
import { T } from "@/components/language-provider";
import { VehiclePlaceholder } from "@/lib/placeholder";
import { getVehicleById } from "@/lib/vehicles";
import { formatMileage, formatPrice, vehicleName } from "@/lib/vehicle-utils";

type Props = {
  params: Promise<{ id: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  const vehicle = await getVehicleById(id);

  if (!vehicle) {
    return { title: "Vehicle Not Found" };
  }

  return {
    title: vehicleName(vehicle),
    description: `${vehicleName(vehicle)} for sale at Moya Auto Sales in Coachella, CA.`,
  };
}

export default async function VehicleDetailPage({ params }: Props) {
  const { id } = await params;
  const vehicle = await getVehicleById(id);

  if (!vehicle || vehicle.hidden) {
    notFound();
  }

  const images = vehicle.vehicle_images ?? [];
  const mainImage = images[0]?.image_url;

  return (
    <section className="bg-white py-10 md:py-14">
      <div className="container-page">
        <Link
          href="/inventory"
          className="mb-6 inline-flex items-center gap-2 text-sm font-black uppercase text-red-700 hover:text-black"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          <T k="common.backInventory" />
        </Link>

        <div className="grid gap-8 lg:grid-cols-[1.15fr_0.85fr]">
          <div>
            <div className="relative aspect-[4/3] overflow-hidden rounded-sm bg-white">
              {mainImage ? (
                <Image
                  src={mainImage}
                  alt={vehicleName(vehicle)}
                  fill
                  priority
                  className="object-cover"
                  sizes="(max-width: 1024px) 100vw, 60vw"
                />
              ) : (
                <VehiclePlaceholder />
              )}
              {vehicle.sold ? (
                <span className="absolute left-4 top-4 bg-black px-4 py-2 text-sm font-black uppercase text-white">
                  <T k="vehicle.sold" />
                </span>
              ) : null}
            </div>
            {images.length > 1 ? (
              <div className="mt-4 grid grid-cols-3 gap-3 md:grid-cols-5">
                {images.slice(1).map((image) => (
                  <div key={image.id} className="relative aspect-[4/3] overflow-hidden rounded-sm bg-white">
                    <Image src={image.image_url} alt={vehicleName(vehicle)} fill className="object-cover" sizes="160px" />
                  </div>
                ))}
              </div>
            ) : null}
          </div>

          <aside className="h-fit rounded-sm border border-black bg-white p-6 shadow-sm">
            <p className="text-sm font-black uppercase tracking-wide text-red-700">
              <T k="vehicle.stock" /> #{vehicle.stock_number}
            </p>
            <h1 className="mt-2 text-3xl font-black uppercase text-black md:text-4xl">
              {vehicleName(vehicle)}
            </h1>
            <div className="mt-5 flex flex-wrap items-center gap-4">
              <p className="text-4xl font-black text-red-700">{formatPrice(vehicle.price)}</p>
              <p className="flex items-center gap-2 text-base font-bold text-black">
                <Gauge className="h-5 w-5" aria-hidden="true" />
                {formatMileage(vehicle.mileage)}
              </p>
            </div>
            <div className="mt-6 grid gap-3 border-t border-black pt-6 text-sm">
              <Spec labelKey="vehicle.vin" value={vehicle.vin} />
              <Spec labelKey="vehicle.type" value={vehicle.vehicle_type} />
              <Spec labelKey="vehicle.transmission" value={vehicle.transmission} />
              <Spec labelKey="vehicle.fuel" value={vehicle.fuel_type} />
              <Spec labelKey="vehicle.exterior" value={vehicle.exterior_color} />
              <Spec labelKey="vehicle.interior" value={vehicle.interior_color} />
            </div>
            <div className="mt-7 grid gap-3 sm:grid-cols-2">
              <a
                href="tel:+17603986692"
                className="focus-ring inline-flex items-center justify-center gap-2 rounded-sm bg-red-700 px-5 py-4 text-sm font-black uppercase text-white hover:bg-black"
              >
                <Phone className="h-4 w-4" aria-hidden="true" />
                <T k="common.callNow" />
              </a>
              <a
                href="https://www.google.com/maps/dir/?api=1&destination=48477%201%2F2%20Grapefruit%20Blvd%2C%20Coachella%2C%20CA%2092236"
                className="focus-ring inline-flex items-center justify-center gap-2 rounded-sm bg-black px-5 py-4 text-sm font-black uppercase text-white hover:bg-red-700"
              >
                <MapPin className="h-4 w-4" aria-hidden="true" />
                <T k="common.getDirections" />
              </a>
            </div>
          </aside>
        </div>

        <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_0.8fr]">
          <section className="rounded-sm border border-black bg-white p-6 shadow-sm">
            <T k="vehicle.description" as="h2" className="text-2xl font-black uppercase text-black" />
            <p className="mt-4 leading-8 text-black">
              {vehicle.description || <T k="vehicle.descriptionFallback" />}
            </p>
          </section>
          <section className="rounded-sm border border-black bg-white p-6 shadow-sm">
            <T k="vehicle.features" as="h2" className="text-2xl font-black uppercase text-black" />
            {vehicle.features?.length ? (
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {vehicle.features.map((feature) => (
                  <p key={feature} className="flex items-center gap-2 text-sm font-bold text-black">
                    <Check className="h-4 w-4 text-red-700" aria-hidden="true" />
                    {feature}
                  </p>
                ))}
              </div>
            ) : (
              <T k="vehicle.featuresFallback" as="p" className="mt-4 text-black" />
            )}
          </section>
        </div>
      </div>
    </section>
  );
}

function Spec({
  labelKey,
  value,
}: {
  labelKey:
    | "vehicle.vin"
    | "vehicle.type"
    | "vehicle.transmission"
    | "vehicle.fuel"
    | "vehicle.exterior"
    | "vehicle.interior";
  value?: string | null;
}) {
  return (
    <div className="flex justify-between gap-4 border-b border-black pb-2">
      <T k={labelKey} className="font-black uppercase text-black" />
      <span className="text-right font-bold text-black">{value || <T k="vehicle.askDealer" />}</span>
    </div>
  );
}

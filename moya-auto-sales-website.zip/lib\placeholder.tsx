import { CarFront } from "lucide-react";
import { T } from "@/components/language-provider";

export function VehiclePlaceholder({ label = "Moya Auto Sales" }: { label?: string }) {
  return (
    <div className="flex h-full min-h-[220px] w-full items-center justify-center bg-white text-black">
      <div className="text-center">
        <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-white shadow-sm">
          <CarFront className="h-8 w-8 text-red-700" aria-hidden="true" />
        </div>
        <p className="text-sm font-bold uppercase tracking-wide">{label}</p>
        <T k="placeholder.photoSoon" as="p" className="mt-1 text-xs uppercase text-black" />
      </div>
    </div>
  );
}

import type { Metadata } from "next";
import { AdminLoginForm } from "@/components/admin-login-form";

export const metadata: Metadata = {
  title: "Admin Login",
};

export default function AdminLoginPage() {
  return (
    <section className="bg-white py-16">
      <div className="container-page max-w-lg">
        <div className="rounded-sm border border-black bg-white p-6 shadow-sm md:p-8">
          <p className="text-sm font-black uppercase tracking-wide text-red-700">Owner Access</p>
          <h1 className="mt-2 text-3xl font-black uppercase text-black">Admin Login</h1>
          <p className="mt-3 text-sm leading-6 text-black">
            Sign in with the private owner account created for Moya Auto Sales.
          </p>
          <div className="mt-6">
            <AdminLoginForm />
          </div>
        </div>
      </div>
    </section>
  );
}

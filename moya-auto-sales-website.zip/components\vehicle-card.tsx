import Image from "next/image";
import Link from "next/link";
import { Gauge } from "lucide-react";
import { T, useLanguage } from "@/components/language-provider";
import type { Vehicle } from "@/lib/types";
import { formatMileage, formatPrice, vehicleName } from "@/lib/vehicle-utils";
import { VehiclePlaceholder } from "@/lib/placeholder";

export function VehicleCard({ vehicle }: { vehicle: Vehicle }) {
  const { t } = useLanguage();
  const mainImage = vehicle.vehicle_images?.[0]?.image_url;

  return (
    <article className="overflow-hidden rounded-sm border border-black bg-white shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg">
      <Link href={`/inventory/${vehicle.id}`} className="block">
        <div className="relative aspect-[4/3] bg-white">
          {mainImage ? (
            <Image
              src={mainImage}
              alt={vehicleName(vehicle)}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 33vw"
            />
          ) : (
            <VehiclePlaceholder />
          )}
          {vehicle.sold ? (
            <span className="absolute left-3 top-3 bg-black px-3 py-1 text-xs font-black uppercase text-white">
              {t("vehicle.sold")}
            </span>
          ) : null}
        </div>
      </Link>
      <div className="p-5">
        <p className="text-lg font-black uppercase text-black">{vehicleName(vehicle)}</p>
        <div className="mt-3 flex items-center justify-between gap-4">
          <p className="text-2xl font-black text-red-700">{formatPrice(vehicle.price)}</p>
          <p className="flex items-center gap-1 text-sm font-bold text-black">
            <Gauge className="h-4 w-4" aria-hidden="true" />
            {formatMileage(vehicle.mileage)}
          </p>
        </div>
        <Link
          href={`/inventory/${vehicle.id}`}
          className="focus-ring mt-5 inline-flex w-full justify-center rounded-sm bg-black px-4 py-3 text-sm font-black uppercase text-white transition hover:bg-red-700"
        >
          <T k="common.viewDetails" />
        </Link>
      </div>
    </article>
  );
}

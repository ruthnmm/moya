"use client";

import { useMemo, useState } from "react";
import { useLanguage } from "@/components/language-provider";
import type { Vehicle } from "@/lib/types";
import { vehicleTypes } from "@/lib/vehicle-utils";
import { VehicleCard } from "@/components/vehicle-card";

export function InventoryFilters({ vehicles }: { vehicles: Vehicle[] }) {
  const { t } = useLanguage();
  const [filters, setFilters] = useState({
    maxPrice: "",
    minYear: "",
    make: "",
    model: "",
    maxMileage: "",
    vehicleType: "",
  });

  const makes = Array.from(new Set(vehicles.map((vehicle) => vehicle.make))).sort();
  const models = Array.from(
    new Set(
      vehicles
        .filter((vehicle) => !filters.make || vehicle.make === filters.make)
        .map((vehicle) => vehicle.model),
    ),
  ).sort();

  const filteredVehicles = useMemo(() => {
    return vehicles.filter((vehicle) => {
      if (filters.maxPrice && vehicle.price > Number(filters.maxPrice)) return false;
      if (filters.minYear && vehicle.year < Number(filters.minYear)) return false;
      if (filters.make && vehicle.make !== filters.make) return false;
      if (filters.model && vehicle.model !== filters.model) return false;
      if (filters.maxMileage && vehicle.mileage > Number(filters.maxMileage)) return false;
      if (filters.vehicleType && vehicle.vehicle_type !== filters.vehicleType) return false;
      return true;
    });
  }, [filters, vehicles]);

  function updateFilter(name: keyof typeof filters, value: string) {
    setFilters((current) => ({
      ...current,
      [name]: value,
      ...(name === "make" ? { model: "" } : {}),
    }));
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[280px_1fr]">
      <aside className="h-fit rounded-sm border border-black bg-white p-5 shadow-sm lg:sticky lg:top-28">
        <p className="text-lg font-black uppercase text-black">{t("filters.title")}</p>
        <div className="mt-5 grid gap-4">
          <FilterInput
            label={t("filters.maxPrice")}
            type="number"
            value={filters.maxPrice}
            onChange={(value) => updateFilter("maxPrice", value)}
            placeholder="25000"
          />
          <FilterInput
            label={t("filters.minYear")}
            type="number"
            value={filters.minYear}
            onChange={(value) => updateFilter("minYear", value)}
            placeholder="2018"
          />
          <FilterSelect
            label={t("filters.make")}
            value={filters.make}
            onChange={(value) => updateFilter("make", value)}
            options={makes}
            anyLabel={t("filters.any")}
          />
          <FilterSelect
            label={t("filters.model")}
            value={filters.model}
            onChange={(value) => updateFilter("model", value)}
            options={models}
            anyLabel={t("filters.any")}
          />
          <FilterInput
            label={t("filters.maxMileage")}
            type="number"
            value={filters.maxMileage}
            onChange={(value) => updateFilter("maxMileage", value)}
            placeholder="80000"
          />
          <FilterSelect
            label={t("filters.type")}
            value={filters.vehicleType}
            onChange={(value) => updateFilter("vehicleType", value)}
            options={[...vehicleTypes]}
            anyLabel={t("filters.any")}
          />
          <button
            type="button"
            onClick={() =>
              setFilters({
                maxPrice: "",
                minYear: "",
                make: "",
                model: "",
                maxMileage: "",
                vehicleType: "",
              })
            }
            className="focus-ring rounded-sm border border-black px-4 py-3 text-sm font-black uppercase text-black hover:border-red-700 hover:text-red-700"
          >
            {t("filters.reset")}
          </button>
        </div>
      </aside>

      <div>
        <div className="mb-5 flex items-center justify-between gap-4">
          <p className="text-sm font-bold uppercase text-black">
            {filteredVehicles.length} {t("filters.available")}
          </p>
        </div>
        {filteredVehicles.length ? (
          <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
            {filteredVehicles.map((vehicle) => (
              <VehicleCard key={vehicle.id} vehicle={vehicle} />
            ))}
          </div>
        ) : (
          <div className="rounded-sm border border-dashed border-black bg-white p-10 text-center">
            <p className="text-lg font-black uppercase text-black">{t("filters.noVehicles")}</p>
            <p className="mt-2 text-sm text-black">{t("filters.noVehiclesCopy")}</p>
          </div>
        )}
      </div>
    </div>
  );
}

function FilterInput({
  label,
  value,
  onChange,
  placeholder,
  type,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  type: string;
}) {
  return (
    <label className="grid gap-2 text-sm font-bold text-black">
      {label}
      <input
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="focus-ring rounded-sm border border-black px-3 py-3"
      />
    </label>
  );
}

function FilterSelect({
  label,
  value,
  onChange,
  options,
  anyLabel,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: string[];
  anyLabel: string;
}) {
  return (
    <label className="grid gap-2 text-sm font-bold text-black">
      {label}
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="focus-ring rounded-sm border border-black px-3 py-3"
      >
        <option value="">{anyLabel}</option>
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </label>
  );
}

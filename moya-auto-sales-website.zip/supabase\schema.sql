-- Moya Auto Sales Supabase setup
-- Run this in the Supabase SQL editor, then create one Auth user for the owner.

create extension if not exists "pgcrypto";

do $$
begin
  if not exists (select 1 from pg_type where typname = 'vehicle_type') then
    create type vehicle_type as enum ('Sedan', 'SUV', 'Truck', 'Coupe', 'Van');
  end if;
end $$;

do $$
begin
  if not exists (select 1 from pg_type where typname = 'lead_type') then
    create type lead_type as enum ('contact', 'financing');
  end if;
end $$;

create table if not exists vehicles (
  id uuid primary key default gen_random_uuid(),
  year integer not null check (year >= 1900),
  make text not null,
  model text not null,
  trim text,
  mileage integer not null default 0 check (mileage >= 0),
  price integer not null default 0 check (price >= 0),
  vin text not null,
  stock_number text not null unique,
  transmission text,
  fuel_type text,
  exterior_color text,
  interior_color text,
  vehicle_type vehicle_type not null default 'Sedan',
  description text,
  features text[] not null default '{}',
  featured boolean not null default false,
  sold boolean not null default false,
  hidden boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists vehicle_images (
  id uuid primary key default gen_random_uuid(),
  vehicle_id uuid not null references vehicles(id) on delete cascade,
  image_url text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists leads (
  id uuid primary key default gen_random_uuid(),
  type lead_type not null default 'contact',
  name text not null,
  phone text,
  monthly_income numeric,
  desired_vehicle text,
  message text,
  created_at timestamptz not null default now()
);

create index if not exists vehicles_public_idx on vehicles (hidden, sold, featured, created_at desc);
create index if not exists vehicle_images_vehicle_id_idx on vehicle_images (vehicle_id, sort_order);
create index if not exists leads_created_at_idx on leads (created_at desc);

alter table vehicles enable row level security;
alter table vehicle_images enable row level security;
alter table leads enable row level security;

drop policy if exists "Public can read visible vehicles" on vehicles;
create policy "Public can read visible vehicles"
on vehicles for select
using (hidden = false);

drop policy if exists "Authenticated admins can manage vehicles" on vehicles;
create policy "Authenticated admins can manage vehicles"
on vehicles for all
to authenticated
using (true)
with check (true);

drop policy if exists "Public can read visible vehicle images" on vehicle_images;
create policy "Public can read visible vehicle images"
on vehicle_images for select
using (
  exists (
    select 1 from vehicles
    where vehicles.id = vehicle_images.vehicle_id
      and vehicles.hidden = false
  )
);

drop policy if exists "Authenticated admins can manage vehicle images" on vehicle_images;
create policy "Authenticated admins can manage vehicle images"
on vehicle_images for all
to authenticated
using (true)
with check (true);

drop policy if exists "Anyone can submit leads" on leads;
create policy "Anyone can submit leads"
on leads for insert
with check (true);

drop policy if exists "Authenticated admins can view leads" on leads;
create policy "Authenticated admins can view leads"
on leads for select
to authenticated
using (true);

insert into storage.buckets (id, name, public)
values ('vehicle-images', 'vehicle-images', true)
on conflict (id) do update set public = true;

drop policy if exists "Public can read vehicle image files" on storage.objects;
create policy "Public can read vehicle image files"
on storage.objects for select
using (bucket_id = 'vehicle-images');

drop policy if exists "Authenticated admins can upload vehicle image files" on storage.objects;
create policy "Authenticated admins can upload vehicle image files"
on storage.objects for insert
to authenticated
with check (bucket_id = 'vehicle-images');

drop policy if exists "Authenticated admins can update vehicle image files" on storage.objects;
create policy "Authenticated admins can update vehicle image files"
on storage.objects for update
to authenticated
using (bucket_id = 'vehicle-images')
with check (bucket_id = 'vehicle-images');

drop policy if exists "Authenticated admins can delete vehicle image files" on storage.objects;
create policy "Authenticated admins can delete vehicle image files"
on storage.objects for delete
to authenticated
using (bucket_id = 'vehicle-images');

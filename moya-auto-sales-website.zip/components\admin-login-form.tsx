"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";

export function AdminLoginForm() {
  const router = useRouter();
  const [message, setMessage] = useState<string | null>(null);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage("Signing in...");
    const formData = new FormData(event.currentTarget);
    const supabase = createSupabaseBrowserClient();
    const { error } = await supabase.auth.signInWithPassword({
      email: String(formData.get("login")),
      password: String(formData.get("password")),
    });

    if (error) {
      setMessage(error.message);
      return;
    }

    router.refresh();
    router.push("/admin");
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-4">
      <label className="grid gap-2 text-sm font-bold text-black">
        Admin Login ID
        <input
          name="login"
          type="text"
          required
          className="focus-ring rounded-sm border border-black px-4 py-3"
        />
      </label>
      <label className="grid gap-2 text-sm font-bold text-black">
        Password
        <input
          name="password"
          type="password"
          required
          className="focus-ring rounded-sm border border-black px-4 py-3"
        />
      </label>
      <button className="focus-ring rounded-sm bg-red-700 px-5 py-4 text-sm font-black uppercase text-white hover:bg-black">
        Login
      </button>
      {message ? <p className="text-sm font-bold text-black">{message}</p> : null}
    </form>
  );
}

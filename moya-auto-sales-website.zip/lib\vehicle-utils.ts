import type { Vehicle } from "@/lib/types";

export const vehicleTypes = ["Sedan", "SUV", "Truck", "Coupe", "Van"] as const;

export function formatPrice(price: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(price);
}

export function formatMileage(mileage: number) {
  return `${new Intl.NumberFormat("en-US").format(mileage)} mi`;
}

export function vehicleName(vehicle: Pick<Vehicle, "year" | "make" | "model" | "trim">) {
  return [vehicle.year, vehicle.make, vehicle.model, vehicle.trim].filter(Boolean).join(" ");
}

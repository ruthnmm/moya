import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { VehicleForm } from "@/components/vehicle-form";
import { getVehicleById } from "@/lib/vehicles";
import { vehicleName } from "@/lib/vehicle-utils";

export const dynamic = "force-dynamic";

type Props = {
  params: Promise<{ id: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  const vehicle = await getVehicleById(id);
  return {
    title: vehicle ? `Edit ${vehicleName(vehicle)}` : "Edit Vehicle",
  };
}

export default async function EditVehiclePage({ params }: Props) {
  const { id } = await params;
  const vehicle = await getVehicleById(id);

  if (!vehicle) {
    notFound();
  }

  return (
    <div>
      <p className="text-sm font-black uppercase text-red-700">Inventory</p>
      <h2 className="mb-6 text-3xl font-black uppercase text-black">
        Edit {vehicleName(vehicle)}
      </h2>
      <VehicleForm vehicle={vehicle} />
    </div>
  );
}

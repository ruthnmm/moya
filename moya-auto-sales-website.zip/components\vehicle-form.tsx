import Image from "next/image";
import { Trash2 } from "lucide-react";
import { createVehicle, deleteVehicle, deleteVehicleImage, updateVehicle } from "@/app/actions/vehicles";
import type { Vehicle } from "@/lib/types";
import { vehicleTypes } from "@/lib/vehicle-utils";

export function VehicleForm({ vehicle }: { vehicle?: Vehicle }) {
  const action = vehicle ? updateVehicle.bind(null, vehicle.id) : createVehicle;

  return (
    <form action={action} className="grid gap-6 rounded-sm border border-black bg-white p-6 shadow-sm">
      <div className="grid gap-4 md:grid-cols-3">
        <Field name="year" label="Year" type="number" required defaultValue={vehicle?.year} />
        <Field name="make" label="Make" required defaultValue={vehicle?.make} />
        <Field name="model" label="Model" required defaultValue={vehicle?.model} />
        <Field name="trim" label="Trim" defaultValue={vehicle?.trim ?? ""} />
        <Field name="mileage" label="Mileage" type="number" required defaultValue={vehicle?.mileage} />
        <Field name="price" label="Price" type="number" required defaultValue={vehicle?.price} />
        <Field name="vin" label="VIN" required defaultValue={vehicle?.vin} />
        <Field name="stock_number" label="Stock Number" required defaultValue={vehicle?.stock_number} />
        <label className="grid gap-2 text-sm font-bold text-black">
          Vehicle Type
          <select
            name="vehicle_type"
            required
            defaultValue={vehicle?.vehicle_type ?? "Sedan"}
            className="focus-ring rounded-sm border border-black px-4 py-3"
          >
            {vehicleTypes.map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </select>
        </label>
        <Field name="transmission" label="Transmission" defaultValue={vehicle?.transmission ?? ""} />
        <Field name="fuel_type" label="Fuel Type" defaultValue={vehicle?.fuel_type ?? ""} />
        <Field name="exterior_color" label="Exterior Color" defaultValue={vehicle?.exterior_color ?? ""} />
        <Field name="interior_color" label="Interior Color" defaultValue={vehicle?.interior_color ?? ""} />
      </div>

      <label className="grid gap-2 text-sm font-bold text-black">
        Vehicle Description
        <textarea
          name="description"
          rows={5}
          defaultValue={vehicle?.description ?? ""}
          className="focus-ring rounded-sm border border-black px-4 py-3"
        />
      </label>

      <label className="grid gap-2 text-sm font-bold text-black">
        Features List
        <textarea
          name="features"
          rows={5}
          defaultValue={vehicle?.features?.join("\n") ?? ""}
          className="focus-ring rounded-sm border border-black px-4 py-3"
          placeholder={"Bluetooth\nBackup Camera\nClean Title"}
        />
      </label>

      <label className="grid gap-2 text-sm font-bold text-black">
        Upload Multiple Images
        <input
          name="images"
          type="file"
          multiple
          accept="image/*"
          className="focus-ring rounded-sm border border-black px-4 py-3"
        />
      </label>

      {vehicle?.vehicle_images?.length ? (
        <div>
          <p className="text-sm font-black uppercase text-black">Current Images</p>
          <div className="mt-3 grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {vehicle.vehicle_images.map((image) => (
              <div key={image.id} className="overflow-hidden rounded-sm border border-black">
                <div className="relative aspect-[4/3]">
                  <Image src={image.image_url} alt="Vehicle image" fill className="object-cover" sizes="180px" />
                </div>
                <button
                  formAction={deleteVehicleImage.bind(null, image.id, vehicle.id)}
                  formNoValidate
                  className="focus-ring flex w-full items-center justify-center gap-2 bg-white px-3 py-2 text-xs font-black uppercase text-red-700 hover:bg-red-50"
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                  Remove
                </button>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-3">
        <Checkbox name="sold" label="Mark Vehicle Sold" checked={vehicle?.sold} />
        <Checkbox name="hidden" label="Hide Vehicle" checked={vehicle?.hidden} />
        <Checkbox name="featured" label="Feature On Homepage" checked={vehicle?.featured} />
      </div>

      <div className="flex flex-col gap-3 border-t border-black pt-5 sm:flex-row">
        <button className="focus-ring rounded-sm bg-red-700 px-5 py-4 text-sm font-black uppercase text-white hover:bg-black">
          {vehicle ? "Save Vehicle" : "Add Vehicle"}
        </button>
        {vehicle ? (
          <button
            formAction={deleteVehicle.bind(null, vehicle.id)}
            formNoValidate
            className="focus-ring rounded-sm border border-red-700 px-5 py-4 text-sm font-black uppercase text-red-700 hover:bg-red-700 hover:text-white"
          >
            Delete Vehicle
          </button>
        ) : null}
      </div>
    </form>
  );
}

function Field({
  name,
  label,
  type = "text",
  required,
  defaultValue,
}: {
  name: string;
  label: string;
  type?: string;
  required?: boolean;
  defaultValue?: string | number;
}) {
  return (
    <label className="grid gap-2 text-sm font-bold text-black">
      {label}
      <input
        name={name}
        type={type}
        required={required}
        defaultValue={defaultValue}
        className="focus-ring rounded-sm border border-black px-4 py-3"
      />
    </label>
  );
}

function Checkbox({ name, label, checked }: { name: string; label: string; checked?: boolean }) {
  return (
    <label className="flex items-center gap-3 rounded-sm border border-black bg-white px-4 py-3 text-sm font-black uppercase text-black">
      <input name={name} type="checkbox" defaultChecked={checked} className="h-5 w-5 accent-red-700" />
      {label}
    </label>
  );
}

import type { Metadata } from "next";
import { LanguageProvider } from "@/components/language-provider";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "https://moyaautosales.com"),
  title: {
    default: "Moya Auto Sales | Used Cars in Coachella, CA",
    template: "%s | Moya Auto Sales",
  },
  description:
    "Moya Auto Sales is a local independent used car dealership serving Coachella and the Coachella Valley with reliable pre-owned vehicles, competitive pricing, and financing options.",
  openGraph: {
    title: "Moya Auto Sales",
    description:
      "Quality used cars, competitive pricing, and financing options for Coachella and the Coachella Valley.",
    url: "/",
    siteName: "Moya Auto Sales",
    locale: "en_US",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "AutoDealer",
    name: "Moya Auto Sales",
    areaServed: ["Coachella", "Coachella Valley", "Indio", "Thermal", "La Quinta"],
    address: {
      "@type": "PostalAddress",
      streetAddress: "48477 1/2 Grapefruit Blvd",
      addressLocality: "Coachella",
      addressRegion: "CA",
      postalCode: "92236",
      addressCountry: "US",
    },
    telephone: "+1-760-398-6692",
    url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://moyaautosales.com",
  };

  return (
    <html lang="en">
      <body>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <LanguageProvider>
          <SiteHeader />
          <main>{children}</main>
          <SiteFooter />
        </LanguageProvider>
      </body>
    </html>
  );
}

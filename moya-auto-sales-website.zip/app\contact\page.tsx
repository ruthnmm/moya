import type { Metadata } from "next";
import { Clock, MapPin, Phone, type LucideIcon } from "lucide-react";
import { T } from "@/components/language-provider";
import { LeadForm } from "@/components/lead-form";

export const metadata: Metadata = {
  title: "Contact",
  description: "Contact Moya Auto Sales in Coachella, CA for used vehicle availability and financing.",
};

export default function ContactPage() {
  return (
    <section className="bg-white py-12 md:py-16">
      <div className="container-page">
        <T k="contact.kicker" as="p" className="text-sm font-black uppercase tracking-wide text-red-700" />
        <T k="contact.title" as="h1" className="mt-2 text-4xl font-black uppercase text-black md:text-5xl" />
        <div className="mt-10 grid gap-8 lg:grid-cols-[0.85fr_1.15fr]">
          <div className="grid gap-5">
            <Info icon={Phone} labelKey="common.phone" value="(760) 398-6692" />
            <Info
              icon={MapPin}
              labelKey="common.address"
              value="48477 1/2 Grapefruit Blvd, Coachella, CA 92236"
            />
            <Info icon={Clock} labelKey="common.hours" valueKey="contact.hoursValue" />
            <div className="grid gap-3 sm:grid-cols-2">
              <a
                href="tel:+17603986692"
                className="focus-ring rounded-sm bg-red-700 px-5 py-4 text-center text-sm font-black uppercase text-white hover:bg-black"
              >
                <T k="common.callNow" />
              </a>
              <a
                href="https://www.google.com/maps/dir/?api=1&destination=48477%201%2F2%20Grapefruit%20Blvd%2C%20Coachella%2C%20CA%2092236"
                className="focus-ring rounded-sm bg-black px-5 py-4 text-center text-sm font-black uppercase text-white hover:bg-red-700"
              >
                <T k="common.getDirections" />
              </a>
            </div>
            <div className="overflow-hidden rounded-sm border border-black bg-white">
              <iframe
                title="Moya Auto Sales map"
                src="https://www.google.com/maps?q=48477%201%2F2%20Grapefruit%20Blvd%2C%20Coachella%2C%20CA%2092236&output=embed"
                className="h-72 w-full border-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
          <div className="rounded-sm border border-black bg-white p-6 shadow-sm md:p-8">
            <LeadForm type="contact" buttonLabel="form.sendMessage" />
          </div>
        </div>
      </div>
    </section>
  );
}

function Info({
  icon: Icon,
  labelKey,
  value,
  valueKey,
}: {
  icon: LucideIcon;
  labelKey: "common.phone" | "common.address" | "common.hours";
  value?: string;
  valueKey?: "contact.hoursValue";
}) {
  return (
    <div className="rounded-sm border border-black bg-white p-5 shadow-sm">
      <Icon className="h-7 w-7 text-red-700" aria-hidden="true" />
      <T k={labelKey} as="p" className="mt-3 text-sm font-black uppercase text-black" />
      {valueKey ? (
        <T k={valueKey} as="p" className="mt-1 font-bold text-black" />
      ) : (
        <p className="mt-1 font-bold text-black">{value}</p>
      )}
    </div>
  );
}

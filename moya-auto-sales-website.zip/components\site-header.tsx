"use client";

import Link from "next/link";
import { Menu, Phone } from "lucide-react";
import { useLanguage } from "@/components/language-provider";

const navItems = [
  { href: "/", label: "nav.home" },
  { href: "/inventory", label: "nav.inventory" },
  { href: "/financing", label: "nav.financing" },
  { href: "/about", label: "nav.about" },
  { href: "/contact", label: "nav.contact" },
] as const;

export function SiteHeader() {
  const { language, setLanguage, t } = useLanguage();

  return (
    <header className="sticky top-0 z-50 border-b border-black bg-white">
      <div className="container-page flex min-h-20 items-center justify-between gap-4 py-3">
        <Link href="/" className="flex items-center" aria-label="Moya Auto Sales home">
          <span className="text-2xl font-black uppercase tracking-wide text-black md:text-3xl">
            Moya Auto Sales
          </span>
        </Link>

        <nav className="hidden items-center gap-6 lg:flex" aria-label="Main navigation">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="text-sm font-black uppercase text-black transition hover:text-red-700"
            >
              {t(item.label)}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <LanguageSwitcher language={language} setLanguage={setLanguage} label={t("nav.language")} />
          <a
            href="tel:+17603986692"
            className="focus-ring inline-flex items-center gap-2 rounded-sm bg-red-700 px-4 py-3 text-sm font-black uppercase text-white transition hover:bg-black"
          >
            <Phone className="h-4 w-4" aria-hidden="true" />
            (760) 398-6692
          </a>
        </div>

        <details className="relative lg:hidden">
          <summary className="focus-ring flex h-11 w-11 cursor-pointer list-none items-center justify-center rounded-sm border border-black text-black">
            <Menu className="h-5 w-5" aria-hidden="true" />
            <span className="sr-only">Open menu</span>
          </summary>
          <div className="absolute right-0 mt-3 w-72 border border-black bg-white p-3 shadow-xl">
            <div className="mb-2 px-3">
              <LanguageSwitcher language={language} setLanguage={setLanguage} label={t("nav.language")} />
            </div>
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="block rounded-sm px-3 py-3 text-sm font-black uppercase text-black hover:bg-red-700 hover:text-white"
              >
                {t(item.label)}
              </Link>
            ))}
            <a
              href="tel:+17603986692"
              className="mt-2 flex items-center justify-center gap-2 rounded-sm bg-red-700 px-3 py-3 text-center text-sm font-black uppercase text-white"
            >
              <Phone className="h-4 w-4" aria-hidden="true" />
              (760) 398-6692
            </a>
          </div>
        </details>
      </div>
    </header>
  );
}

function LanguageSwitcher({
  language,
  setLanguage,
  label,
}: {
  language: "en" | "es";
  setLanguage: (language: "en" | "es") => void;
  label: string;
}) {
  return (
    <select
      value={language}
      onChange={(event) => setLanguage(event.target.value as "en" | "es")}
      className="focus-ring rounded-sm border border-black bg-white px-3 py-2 text-sm font-black uppercase text-black"
      aria-label={label}
    >
      <option value="en">English</option>
      <option value="es">Español</option>
    </select>
  );
}

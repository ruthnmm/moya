import { cache } from "react";
import { createSupabaseServerClient, hasSupabaseEnv } from "@/lib/supabase/server";
import type { Vehicle } from "@/lib/types";

const vehicleSelect = "*, vehicle_images(*)";

export const getVisibleVehicles = cache(async () => {
  if (!hasSupabaseEnv()) {
    return [] as Vehicle[];
  }

  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase
    .from("vehicles")
    .select(vehicleSelect)
    .eq("hidden", false)
    .order("featured", { ascending: false })
    .order("created_at", { ascending: false });

  if (error) {
    console.error(error);
    return [] as Vehicle[];
  }

  return (data ?? []) as Vehicle[];
});

export const getFeaturedVehicles = cache(async () => {
  const vehicles = await getVisibleVehicles();
  return vehicles.filter((vehicle) => vehicle.featured && !vehicle.sold).slice(0, 6);
});

export const getVehicleById = cache(async (id: string) => {
  if (!hasSupabaseEnv()) {
    return null;
  }

  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase
    .from("vehicles")
    .select(vehicleSelect)
    .eq("id", id)
    .single();

  if (error) {
    console.error(error);
    return null;
  }

  return data as Vehicle;
});

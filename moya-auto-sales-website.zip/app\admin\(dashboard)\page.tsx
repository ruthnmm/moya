import Link from "next/link";
import { EyeOff, Plus, Star, type LucideIcon } from "lucide-react";
import { createSupabaseAdminClient } from "@/lib/supabase/server";
import { formatMileage, formatPrice, vehicleName } from "@/lib/vehicle-utils";
import type { Vehicle } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function AdminHomePage() {
  const supabase = createSupabaseAdminClient();
  const { data } = await supabase
    .from("vehicles")
    .select("*, vehicle_images(*)")
    .order("created_at", { ascending: false });
  const vehicles = (data ?? []) as Vehicle[];

  return (
    <div className="grid gap-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <p className="text-sm font-black uppercase text-red-700">Inventory Manager</p>
          <h2 className="text-3xl font-black uppercase text-black">Vehicles</h2>
        </div>
        <Link
          href="/admin/vehicles/new"
          className="focus-ring inline-flex w-fit items-center gap-2 rounded-sm bg-red-700 px-5 py-4 text-sm font-black uppercase text-white hover:bg-black"
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
          Add Vehicle
        </Link>
      </div>

      <div className="overflow-x-auto rounded-sm border border-black bg-white shadow-sm">
        <table className="w-full min-w-[900px] border-collapse text-left text-sm">
          <thead className="bg-black text-white">
            <tr>
              <Th>Vehicle</Th>
              <Th>Price</Th>
              <Th>Mileage</Th>
              <Th>Status</Th>
              <Th>Photos</Th>
              <Th>Actions</Th>
            </tr>
          </thead>
          <tbody>
            {vehicles.map((vehicle) => (
              <tr key={vehicle.id} className="border-t border-black">
                <td className="px-4 py-4">
                  <p className="font-black uppercase text-black">{vehicleName(vehicle)}</p>
                  <p className="mt-1 text-xs font-bold uppercase text-red-700">
                    Stock #{vehicle.stock_number}
                  </p>
                </td>
                <td className="px-4 py-4 font-bold">{formatPrice(vehicle.price)}</td>
                <td className="px-4 py-4 font-bold">{formatMileage(vehicle.mileage)}</td>
                <td className="px-4 py-4">
                  <div className="flex flex-wrap gap-2">
                    {vehicle.featured ? <Badge icon={Star} label="Featured" /> : null}
                    {vehicle.hidden ? <Badge icon={EyeOff} label="Hidden" /> : null}
                    {vehicle.sold ? <Badge label="Sold" /> : <Badge label="Available" />}
                  </div>
                </td>
                <td className="px-4 py-4 font-bold">{vehicle.vehicle_images?.length ?? 0}</td>
                <td className="px-4 py-4">
                  <Link
                    href={`/admin/vehicles/${vehicle.id}/edit`}
                    className="focus-ring rounded-sm border border-black px-4 py-2 text-xs font-black uppercase text-black hover:border-red-700 hover:text-red-700"
                  >
                    Edit
                  </Link>
                </td>
              </tr>
            ))}
            {!vehicles.length ? (
              <tr>
                <td className="px-4 py-10 text-center font-bold text-black" colSpan={6}>
                  No vehicles yet. Add your first inventory listing.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Th({ children }: { children: React.ReactNode }) {
  return <th className="px-4 py-3 text-xs font-black uppercase tracking-wide">{children}</th>;
}

function Badge({
  label,
  icon: Icon,
}: {
  label: string;
  icon?: LucideIcon;
}) {
  return (
    <span className="inline-flex items-center gap-1 rounded-sm border border-black bg-white px-2 py-1 text-xs font-black uppercase text-black">
      {Icon ? <Icon className="h-3 w-3 text-red-700" aria-hidden="true" /> : null}
      {label}
    </span>
  );
}

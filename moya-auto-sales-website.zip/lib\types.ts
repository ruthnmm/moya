export type VehicleType = "Sedan" | "SUV" | "Truck" | "Coupe" | "Van";

export type VehicleImage = {
  id: string;
  vehicle_id: string;
  image_url: string;
  sort_order?: number | null;
};

export type Vehicle = {
  id: string;
  year: number;
  make: string;
  model: string;
  trim: string | null;
  mileage: number;
  price: number;
  vin: string;
  stock_number: string;
  transmission: string | null;
  fuel_type: string | null;
  exterior_color: string | null;
  interior_color: string | null;
  vehicle_type: VehicleType;
  description: string | null;
  features: string[] | null;
  featured: boolean;
  sold: boolean;
  hidden: boolean;
  created_at: string;
  vehicle_images?: VehicleImage[];
};

export type LeadType = "contact" | "financing";

export type Lead = {
  id: string;
  type: LeadType;
  name: string;
  phone: string | null;
  monthly_income: number | null;
  desired_vehicle: string | null;
  message: string | null;
  created_at: string;
};

import type { Metadata } from "next";
import { createSupabaseAdminClient } from "@/lib/supabase/server";
import type { Lead } from "@/lib/types";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Customer Leads",
};

export default async function LeadsPage() {
  const supabase = createSupabaseAdminClient();
  const { data } = await supabase.from("leads").select("*").order("created_at", { ascending: false });
  const leads = (data ?? []) as Lead[];

  return (
    <div>
      <p className="text-sm font-black uppercase text-red-700">Customer Leads</p>
      <h2 className="mb-6 text-3xl font-black uppercase text-black">
        Financing & Contact Submissions
      </h2>
      <div className="grid gap-4">
        {leads.map((lead) => (
          <article key={lead.id} className="rounded-sm border border-black bg-white p-5 shadow-sm">
            <div className="flex flex-col justify-between gap-3 md:flex-row">
              <div>
                <p className="text-xs font-black uppercase tracking-wide text-red-700">{lead.type}</p>
                <h3 className="text-xl font-black uppercase text-black">{lead.name}</h3>
                <p className="mt-1 text-sm text-black">
                  {new Date(lead.created_at).toLocaleString("en-US")}
                </p>
              </div>
              <div className="text-sm font-bold text-black md:text-right">
                <p>{lead.phone || "No phone"}</p>
              </div>
            </div>
            {lead.message ? <p className="mt-4 leading-7 text-black">{lead.message}</p> : null}
          </article>
        ))}
        {!leads.length ? (
          <div className="rounded-sm border border-dashed border-black bg-white p-10 text-center font-bold text-black">
            No customer leads yet.
          </div>
        ) : null}
      </div>
    </div>
  );
}

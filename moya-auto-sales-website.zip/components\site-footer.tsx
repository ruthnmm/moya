"use client";

import Link from "next/link";
import { Clock, MapPin, Phone } from "lucide-react";
import { T } from "@/components/language-provider";

export function SiteFooter() {
  return (
    <footer className="bg-black text-white">
      <div className="container-page grid gap-10 py-12 md:grid-cols-[1.2fr_1fr_1fr]">
        <div>
          <p className="text-2xl font-black uppercase">Moya Auto Sales</p>
          <T k="footer.copy" as="p" className="mt-3 max-w-md text-sm leading-6 text-white" />
        </div>
        <div>
          <T k="footer.visit" as="p" className="text-sm font-black uppercase text-red-500" />
          <div className="mt-4 space-y-3 text-sm text-white">
            <p className="flex gap-2">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-red-500" aria-hidden="true" />
              48477 1/2 Grapefruit Blvd, Coachella, CA 92236
            </p>
            <p className="flex gap-2">
              <Phone className="mt-0.5 h-4 w-4 shrink-0 text-red-500" aria-hidden="true" />
              (760) 398-6692
            </p>
            <p className="flex gap-2">
              <Clock className="mt-0.5 h-4 w-4 shrink-0 text-red-500" aria-hidden="true" />
              <T k="contact.hoursValue" />
            </p>
          </div>
        </div>
        <div>
          <T k="footer.links" as="p" className="text-sm font-black uppercase text-red-500" />
          <div className="mt-4 grid gap-2 text-sm">
            <Link href="/inventory" className="text-white hover:text-red-500">
              <T k="nav.inventory" />
            </Link>
            <Link href="/financing" className="text-white hover:text-red-500">
              <T k="common.applyFinancing" />
            </Link>
            <Link href="/contact" className="text-white hover:text-red-500">
              <T k="nav.contact" />
            </Link>
          </div>
        </div>
      </div>
      <div className="border-t border-white py-5">
        <T k="footer.disclaimer" as="div" className="container-page text-xs text-white" />
      </div>
    </footer>
  );
}

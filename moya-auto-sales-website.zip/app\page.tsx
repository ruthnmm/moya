import Image from "next/image";
import Link from "next/link";
import { ArrowRight, BadgeCheck, CarFront, ClipboardCheck } from "lucide-react";
import { T } from "@/components/language-provider";
import { SectionHeading } from "@/components/section-heading";
import { VehicleCard } from "@/components/vehicle-card";
import { WhyChooseUs } from "@/components/why-choose-us";
import { getFeaturedVehicles } from "@/lib/vehicles";

export default async function HomePage() {
  const featuredVehicles = await getFeaturedVehicles();

  return (
    <>
      <section className="bg-black text-white">
        <div className="container-page grid min-h-[620px] items-center gap-10 py-14 lg:grid-cols-[1.05fr_0.95fr]">
          <div>
            <T k="home.kicker" as="p" className="text-sm font-black uppercase tracking-wide text-red-500" />
            <T
              k="home.headline"
              as="h1"
              className="mt-5 max-w-4xl text-5xl font-black uppercase leading-tight md:text-6xl"
            />
            <T k="home.subheadline" as="p" className="mt-6 max-w-2xl text-lg leading-8 text-white" />
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link
                href="/inventory"
                className="focus-ring inline-flex items-center justify-center gap-2 rounded-sm bg-red-700 px-6 py-4 text-sm font-black uppercase text-white transition hover:bg-white hover:text-black"
              >
                <T k="common.viewInventory" />
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
              <Link
                href="/financing"
                className="focus-ring inline-flex items-center justify-center rounded-sm border border-white px-6 py-4 text-sm font-black uppercase text-white transition hover:bg-white hover:text-black"
              >
                <T k="common.applyFinancing" />
              </Link>
            </div>
          </div>
          <div className="grid gap-4">
            <div className="overflow-hidden rounded-sm border border-white bg-black">
              <Image
                src="/moya-auto-sales-banner.png"
                alt="Moya Auto Sales"
                width={1600}
                height={900}
                className="h-auto w-full object-contain"
                priority
              />
              <div className="border-t border-white p-5">
                <T k="home.heroCardTitle" as="p" className="text-2xl font-black uppercase text-white" />
                <T k="home.heroCardCopy" as="p" className="mt-3 leading-7 text-white" />
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-sm border border-white bg-black p-5">
                <BadgeCheck className="h-8 w-8 text-red-500" aria-hidden="true" />
                <T k="home.reliable" as="p" className="mt-3 font-black uppercase" />
              </div>
              <div className="rounded-sm border border-white bg-black p-5">
                <ClipboardCheck className="h-8 w-8 text-red-500" aria-hidden="true" />
                <T k="home.applications" as="p" className="mt-3 font-black uppercase" />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="container-page">
          <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <SectionHeading
              kickerKey="home.featuredKicker"
              titleKey="home.featuredTitle"
              copyKey="home.featuredCopy"
            />
            <Link
              href="/inventory"
              className="focus-ring inline-flex w-fit items-center gap-2 rounded-sm bg-black px-5 py-3 text-sm font-black uppercase text-white transition hover:bg-red-700"
            >
              <T k="common.viewAll" />
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </div>
          {featuredVehicles.length ? (
            <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {featuredVehicles.map((vehicle) => (
                <VehicleCard key={vehicle.id} vehicle={vehicle} />
              ))}
            </div>
          ) : (
            <div className="mt-10 rounded-sm border border-dashed border-black bg-white p-10 text-center">
              <CarFront className="mx-auto h-12 w-12 text-red-700" aria-hidden="true" />
              <T k="home.noInventoryTitle" as="p" className="mt-4 text-xl font-black uppercase text-black" />
              <T k="home.noInventoryCopy" as="p" className="mx-auto mt-3 max-w-xl text-black" />
            </div>
          )}
        </div>
      </section>

      <WhyChooseUs />
    </>
  );
}
